/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.banklockers;

import java.util.Scanner;

/**
 *
 * @author imad
 */
public class OperacionesBancarias {
    private Scanner scanner = new Scanner(System.in);
    
    private Double obtenerMontoValido(String mensaje, Double saldo){
        boolean valor = true;
        while(valor){
            Double monto = ingresarDepositoValido(mensaje);
            if(monto<= saldo ){
                return monto;
            }
            else{
                System.out.println("El monto solicitado es mayor al saldo");
            }
        }
        return 0.0;
    }
    
    
    private Double ingresarDepositoValido(String mensaje){
        double monto = -1;
        while (monto <= 0) {
            System.out.println(mensaje);
            if (scanner.hasNextDouble()) {
                monto = scanner.nextDouble();
                if (monto <= 0) {
                    System.out.println("El monto debe ser mayor que cero. Intente de nuevo.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                scanner.next(); // Descarta la entrada no válida
            }
        }
        return monto;
    }
    public Double retiro(Cliente cliente){
        System.out.println("================================================");
        System.out.println("  Retiro del cliente  ");
        System.out.println("================================================");
        System.out.println("================================================");
        System.out.println("  Atendiendo a " + cliente.getNombreCompleto() + " " + cliente.getApellido());
        
        Double monto = obtenerMontoValido("Ingrese el monto que desea retirar", cliente.getSaldo());
        System.out.println("saldo: " + cliente.getSaldo() + " monto operacion: " + monto + " saldo actualizado: "+(cliente.getSaldo()-monto));
        cliente.setSaldo(cliente.getSaldo()-monto);
        
        System.out.println("Operacion en proceso espere un momento");
        return monto;
        
    }
    
    public Double deposito(Cliente cliente){
        System.out.println("================================================");
        System.out.println("  Deposito del cliente  ");
        System.out.println("================================================");
        System.out.println("================================================");
        System.out.println("  Atendiendo a " + cliente.getNombreCompleto() + " " + cliente.getApellido());
        
        Double monto = ingresarDepositoValido("Ingrese el monto que desea depositar");
        System.out.println("saldo: " + cliente.getSaldo() + " monto operacion: " + monto + " saldo actualizado: "+(cliente.getSaldo()+monto));
        cliente.setSaldo(cliente.getSaldo()+monto);
        System.out.println("Operacion en proceso espere un momento");
        return monto;
    }
    
    public Double actualizacionLibreta(Cliente cliente){
        System.out.println("================================================");
        System.out.println("  Actualizacion de libreta del cliente  ");
        System.out.println("================================================");
        System.out.println("================================================");
        System.out.println("  Atendiendo a " + cliente.getNombreCompleto() + " " + cliente.getApellido());
        System.out.println("Libreta actualizada");
        return 0.00;
    }
    
    public void consultaMovimiento(){
        
    }
    
    public Double pagoServicios(Cliente cliente) {
        System.out.println("================================================");
        System.out.println("  Pago de servicios del cliente  ");
        System.out.println("================================================");
        System.out.println("================================================");
        System.out.println("  Atendiendo a " + cliente.getNombreCompleto() + " " + cliente.getApellido());
        
        Double monto = obtenerMontoValido("Ingrese el monto que desea pagar el servicio", cliente.getSaldo());
        System.out.println("saldo: " + cliente.getSaldo() + " monto operacion: " + monto + " saldo actualizado: "+(cliente.getSaldo()-monto));
        cliente.setSaldo(cliente.getSaldo()-monto);
        System.out.println("Operacion en proceso espere un momento");
        return monto;
    }
}
